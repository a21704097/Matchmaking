import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {FireAuthService} from '../fire-auth.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-registar',
  templateUrl: './registar.page.html',
  styleUrls: ['./registar.page.scss'],
})
export class RegistarPage implements OnInit {

  public validationsForm: FormGroup;
  public errorMessage = '';
  public successMessage = '';
  public validationMessages = {
    email: [
      {type: 'required', message: 'Email necessário.'},
      {type: 'pattern', message: 'Insira um email válido.'}
    ],
    password: [
      {type: 'required', message: 'Password necessária.'},
      {type: 'minlength', message: 'Password deve ter no mínimo 6 caracteres.'}
    ]
  };
  constructor(
      private authService: FireAuthService,
      private formBuilder: FormBuilder,
      private router: Router
  ) {
  }
  public ngOnInit(): void {
    this.validationsForm = this.formBuilder.group({
      email: new FormControl('', Validators.compose([
        Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  ])),
    password: new FormControl('', Validators.compose([
      Validators.minLength(5),
      Validators.required
    ])),
  });
  }
  public tryRegister(value: { email: string, password: string }): void {
    this.authService.doRegister(value)
        .then(res => {
          console.log(res);
          this.errorMessage = '';
          this.successMessage = 'Conta criada! Faça Login.';
        }, err => {
          console.log(err);
          this.errorMessage = err.message;
          this.successMessage = '';
        });
  }
  public goLoginPage(): void {
    this.router.navigate(['/login']);
  }
}
