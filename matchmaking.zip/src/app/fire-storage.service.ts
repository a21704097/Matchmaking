import { Injectable } from '@angular/core';
import { Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class FireStorageService {
  private unsubscribe: Subject<void> = new Subject<void>();
  constructor() {
  }
  public unsubscribeOnLogout(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
